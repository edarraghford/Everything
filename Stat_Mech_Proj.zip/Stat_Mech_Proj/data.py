from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, utils
from skimage import io
import torchvision.transforms.functional as TF
from PIL import Image
import numpy as np 
from random import randint 

import warnings
warnings.filterwarnings("ignore")

class SimulationsDataset(Dataset):

    def __init__(self, energy_file): #, train=True):
        self.energy = np.loadtxt(energy_file) 

    def transform(self, image, energy):
        image = TF.resize(image, 32, interpolation=0)
        image = TF.to_tensor(image)
#        image = image*energy 
        return image

    def __getitem__(self,index):
        real = Image.open('simulation' + str(index) + '.png') 
        fake = Image.open('random' + str(index) + '.png')     
        
        real = real.convert('L')
        fake = fake.convert('L') 
        E_real = self.energy[index]
        N1 = randint(0,299) 
        N2 = (randint(1,299)+index)%300 
        E_fake1 = self.energy[N1]
        E_fake2 = self.energy[N2]  
        real1 = self.transform(real, E_real)
        fake1 = self.transform(fake, E_fake1)
        fake2 = self.transform(real, E_fake2) 
        
        return real1, fake1, fake2 

    def __len__(self):
        return 10000

