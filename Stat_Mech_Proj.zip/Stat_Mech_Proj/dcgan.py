from IPython import display
import matplotlib.pyplot as plt 
import torch
from torch import nn
from torch.optim import Adam
from torch.autograd import Variable
import data 
import torchvision.transforms.functional as TF
import numpy as np 
from torchvision.transforms import ToPILImage

from torchvision import transforms, datasets

class DiscriminativeNet(torch.nn.Module):
    
    def __init__(self):
        super(DiscriminativeNet, self).__init__()
        
        self.conv1 = nn.Sequential(
            nn.Conv2d(
                in_channels=1, out_channels=128, kernel_size=4, 
                stride=2, padding=1, bias=False
            ),
            nn.LeakyReLU(0.2, inplace=True)
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(
                in_channels=128, out_channels=256, kernel_size=4,
                stride=2, padding=1, bias=False
            ),
            nn.BatchNorm2d(256),
            nn.LeakyReLU(0.2, inplace=True)
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(
                in_channels=256, out_channels=512, kernel_size=4,
                stride=2, padding=1, bias=False
            ),
            nn.BatchNorm2d(512),
            nn.LeakyReLU(0.2, inplace=True)
        )
        self.conv4 = nn.Sequential(
            nn.Conv2d(
                in_channels=512, out_channels=1024, kernel_size=4,
                stride=2, padding=1, bias=False
            ),
            nn.BatchNorm2d(1024),
            nn.LeakyReLU(0.2, inplace=True)
        )
        self.out = nn.Sequential(
            nn.Linear(1024*2*2, 1),
            nn.Sigmoid(),
        )

    def forward(self, x):
        # Convolutional layers
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        x = self.conv4(x)
        # Flatten and apply sigmoid
        x = x.view(-1, 1024*2*2)
        x = self.out(x)
        return x


class GenerativeNet(torch.nn.Module):
    
    def __init__(self):
        super(GenerativeNet, self).__init__()
        
        self.linear = torch.nn.Linear(100, 1024*2*2)
        
        self.conv1 = nn.Sequential(
            nn.ConvTranspose2d(
                in_channels=1024, out_channels=512, kernel_size=4,
                stride=2, padding=1, bias=False
            ),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True)
        )
        self.conv2 = nn.Sequential(
            nn.ConvTranspose2d(
                in_channels=512, out_channels=256, kernel_size=4,
                stride=2, padding=1, bias=False
            ),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True)
        )
        self.conv3 = nn.Sequential(
            nn.ConvTranspose2d(
                in_channels=256, out_channels=128, kernel_size=4,
                stride=2, padding=1, bias=False
            ),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True)
        )
        self.conv4 = nn.Sequential(
            nn.ConvTranspose2d(
                in_channels=128, out_channels=1, kernel_size=4,
                stride=2, padding=1, bias=False
            )
        )
        self.out = torch.nn.Tanh()

    def forward(self, x):
        # Project and reshape
        x = self.linear(x)
        x = x.view(x.shape[0], 1024, 2, 2)
        # Convolutional layers
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        x = self.conv4(x)
        # Apply Tanh
        return self.out(x)

def noise(size):
    n = Variable(torch.randn(size,100))
    if torch.cuda.is_available(): return n.cuda()
#    n = Variable(TF.to_tensor(2*np.random.randint(2, size=(size,100))-1))
    return n 


def init_weights(m):
    classname = m.__class__.__name__
    if classname.find('Conv') != -1 or classname.find('BatchNorm') != -1:
        m.weight.data.normal_(0.00, 0.02)


# Create Network instances and init weights
generator = GenerativeNet()
generator.apply(init_weights)

discriminator = DiscriminativeNet()
discriminator.apply(init_weights)

g_optimizer = Adam(generator.parameters(), lr=0.0002, betas=(0.5, 0.999))
d_optimizer = Adam(discriminator.parameters(), lr=0.0002, betas=(0.5, 0.999))

# Loss function
loss = nn.BCELoss()

# Number of epochs
num_epochs = 300

def real_data_target(size):
    '''
    Tensor containing ones, with shape = size
    '''
    data = Variable(torch.ones(size, 1))
    if torch.cuda.is_available(): return data.cuda()
    return data

def fake_data_target(size):
    '''
    Tensor containing zeros, with shape = size
    '''
    data = Variable(torch.zeros(size, 1))
    if torch.cuda.is_available(): return data.cuda()
    return data

def train_discriminator(optimizer, real_data, fake_data1, fake_data2):
    # Reset gradients
    optimizer.zero_grad()
    # 1. Train on Real Data
    prediction_real = discriminator(real_data)
    # Calculate error and backpropagate
    error_real = loss(prediction_real, real_data_target(real_data.size(0)))
    error_real.backward()

    # 2. Train on Fake Data
    prediction_fake1 = discriminator(fake_data1)
    # Calculate error and backpropagate
    error_fake1 = loss(prediction_fake1, fake_data_target(real_data.size(0)))
    error_fake1.backward()

    prediction_fake2 = discriminator(fake_data2)
    # Calculate error and backpropagate
    error_fake2 = loss(prediction_fake2, fake_data_target(real_data.size(0)))
    error_fake2.backward()
    # Update weights with gradients
    optimizer.step()
    
    return error_real + error_fake1 + error_fake2, prediction_real, prediction_fake1, prediction_fake2
    return (0, 0, 0)

def train_generator(optimizer, fake_data):
    # Reset gradients
    optimizer.zero_grad()
    # Sample noise and generate fake data
    prediction = discriminator(fake_data)
    # Calculate error and backpropagate
    error = loss(prediction, real_data_target(prediction.size(0)))
    error.backward()
    # Update weights with gradients
    optimizer.step()
    # Return error
    return error

batch_size = 50
data_loader = torch.utils.data.DataLoader(data.SimulationsDataset(energy_file='energy.txt'), batch_size=batch_size, shuffle=True)
num_batches = len(data_loader)
num_test_samples = 1 
test_noise = noise(num_test_samples) 

for epoch in range(num_epochs):
    for n_batch, (real_batch,fake_batch1, fake_batch2) in enumerate(data_loader):
       
        # 1. Train Discriminator
        real_data = Variable(real_batch)
       
        if torch.cuda.is_available(): real_data = real_data.cuda()
        # Generate fake data
        fake_data1 = Variable(fake_batch1) 
        fake_data2 = Variable(fake_batch2) 
        # Train D
        d_error, d_pred_real, d_pred_fake1, d_pred_fake2 = train_discriminator(d_optimizer, 
                                                                real_data, fake_data1, fake_data2)
        print(d_error) 

        # Generate fake data
        fake_data = generator(noise(real_batch.size(0)))
        # Train G
        g_error = train_generator(g_optimizer, fake_data)
        # Log error
        if (n_batch) % 5 == 0:        
        # Display Progress
            # Display Images
           
            test_images = generator(test_noise)
            test_images = test_images.detach().numpy()
         #   ene = np.max(test_images)
         #   print(ene)
         #   test_images = test_images/ene 
            print(test_images.shape) 
            test_images = test_images[0][0] #.transpose(1,2,0)[0]  # , mode='RGB') 
            plt.imshow(test_images, cmap=plt.cm.binary)
            file_name = 'test_image' + str(epoch) + '.png' 
            plt.savefig(file_name) 
            # Display status Logs
            
