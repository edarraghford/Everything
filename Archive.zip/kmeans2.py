from sklearn.cluster import KMeans
import numpy as np
import matplotlib.pyplot as plt  
from mpl_toolkits.mplot3d import axes3d, Axes3D  
import pandas as pd 
from sklearn.datasets import make_blobs
from sklearn.mixture import GaussianMixture as GMM 

def get_data(file_name):
    data =  np.genfromtxt('giant_table.dat', invalid_raise=False, missing_values='NaN', filling_values=0.0)  
    symmetry = data[:,12]
    symmetry_err = data[:,19]
    peakiness = data[:,1]
    peakiness_err = data[:,18]
    alignment = data[:,11]
    alignment_err = data[:,20]
    ellipticity = data[:,21]
    ellipticity_err = data[:,22]
    ellipticity_slope = data[:,23]
    ellipticity_slope_err = data[:,24]
    return symmetry, symmetry_err, peakiness, peakiness_err, alignment, alignment_err, ellipticity, ellipticity_err, ellipticity_slope, ellipticity_slope_err 




symmetry, symmetry_err, peakiness, peakiness_err, alignment, alignment_err, ellipticity, ellipticity_err, ellipticity_slope, ellipticity_slope_err = get_data('giant_table_all.tex') 

print(symmetry) 
sym = symmetry[~(symmetry==0)] 
sym_err = symmetry_err[~(symmetry==0)] 
peak = peakiness[~(symmetry==0)]
peak_err = peakiness_err[~(symmetry==0)]
align = alignment[~(symmetry==0)]
align_err = alignment_err[~(symmetry==0)]
ellipt = ellipticity[~(symmetry==0)]
ellipt_err = ellipticity_err[~(symmetry==0)]
ellipt_slope = ellipticity_slope[~(symmetry==0)]
ellipt_slope_err = ellipticity_slope_err[~(symmetry==0)]

sym = sym[~np.isnan(ellipt_slope)]
peak = peak[~np.isnan(ellipt_slope)]
align = align[~np.isnan(ellipt_slope)]
ellipt = ellipt[~np.isnan(ellipt_slope)]
ellipt_slope = ellipt_slope[~np.isnan(ellipt_slope)]
print(ellipt_slope) 
X = np.array(list(zip(sym, align,peak,  ellipt, ellipt_slope)))

print(np.mean(peak)) 

kmeans = KMeans(n_clusters=2)
kmeans = kmeans.fit(X)
labels_kmeans = kmeans.predict(X)
centroids = kmeans.cluster_centers_

gmm = GMM(n_components=2).fit(X)
labels_gmm = gmm.predict(X)

print(centroids)

#plt.rcParams['figure.figsize'] = (16, 9)

#fig = plt.figure()
#ax = Axes3D(fig)
#ax.scatter(X[:, 0], X[:, 1], X[:,2], c=labels)
#ax.scatter(centroids[:, 0], centroids[:, 1],centroids[:,2],  marker='*', c='#050505', s=1000)
#plt.show()

fig, ax = plt.subplots()
ax.scatter(sym, align, marker='o', c=labels_kmeans) #,ecolor='lightgray', elinewidth=3)
ax.set_xlabel('symmetry')
ax.set_ylabel('alignment')
ax.axvline(x=0.87, linestyle='--')
ax.axhline(y=1.0, linestyle='--')

plt.show()


fig, ax = plt.subplots()
ax.scatter(peak, align, marker = 'o', c=labels_kmeans) #,ecolor='lightgray', elinewidth=3)
ax.set_xlabel('peakiness')
ax.set_ylabel('alignment')
ax.axvline(x=-0.82, linestyle='--')
ax.axhline(y=1.0, linestyle='--')

plt.show()

fig, ax = plt.subplots()
ax.scatter(peak, sym, marker='o', c=labels_kmeans) # ,ecolor='lightgray', elinewidth=3)
ax.set_xlabel('peakiness')
ax.set_ylabel('symmetry')
ax.axvline(x=-0.82, linestyle='--')
ax.axhline(y=0.87, linestyle='--')

plt.show()
