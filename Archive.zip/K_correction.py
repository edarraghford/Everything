from astropy.io import fits
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from PIL import Image
import scipy.optimize as opt
from matplotlib.colors import LogNorm
import matplotlib
from astropy.convolution import convolve, Box2DKernel
from astropy import wcs
import sys
import xspec
from astropy import cosmology
from astropy.cosmology import FlatLambdaCDM
import astropy.units as u
import pandas as pd
import os
import copy
from astropy.stats import bootstrap as bstrap
import pyregion
from numba import jit


def get_K_correction_simulation(z, kT = 5., abund = .3, nH = 0., Eobs = '0.1-2.4', Ez = '0.1-2.4', thermal = 'apec',
                     absorption = 'phabs', solar = 'aspl'):

    xspec.Xset.chatter = 9
    xspec.Xset.abund = solar
    m = xspec.Model(absorption + '*' + thermal)
    xspec.AllData.dummyrsp(0.01, 100.0, 200)


    ab = m.__getattribute__(absorption)
    ab.nH = 0.0
    thermal = m.__getattribute__(thermal)
    thermal.kT = kT
    thermal.Abundanc = abund

    Estr = ' '.join(Ez.split('-'))
    xspec.AllModels.calcFlux( Estr )
    Fintrinsic = m.flux[0]

    ab.nH = nH * 1.0e-22 # xspec units
    Estr = ' '.join([str(y) for y in [float(x)*(1.0+z) for x in Eobs.split('-')]])
    xspec.AllModels.calcFlux( Estr )
    Fobs = m.flux[0]
    correction = m.flux[3]/m.flux[0]

    return Fobs/Fintrinsic, correction

z = np.linspace(0,1.5, 50) 
kT = np.linspace(2,12, 50) 

map = np.zeros((len(z), len(kT)))

for i in range(len(z)):
    for j in range(len(kT)):
        a, correct = get_K_correction_simulation(z[i], kT[j])
        map[i][j] = correct 
print(map)
