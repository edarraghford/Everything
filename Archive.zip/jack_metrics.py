import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 

sym_err = np.zeros((2,7)) 
align_err = np.zeros((2,7))
peak_err = np.zeros((2,7))
sym = np.zeros(7)
align = np.zeros(7)
peak = np.zeros(7)

for i in range(7):
	file_name = 'final_metrics' + str(i) + '.csv'
	data = pd.read_csv(file_name)
	sym_err[:,i] = np.nanquantile(data['Symmetry'], [0.25,0.75])  
	align_err[:,i] = np.nanquantile(data['Alignment'], [0.25,0.75])
	peak_err[:,i] = np.nanquantile(data['Peakiness'], [0.25,0.75])
	sym[i] = np.nanmedian(data['Symmetry'])  
	align[i] = np.nanmedian(data['Alignment'])
	peak[i] = np.nanmedian(data['Peakiness'])

sym_err = np.abs(sym_err-sym)
peak_err = np.abs(peak_err-peak)
align_err = np.abs(align_err-align)

plt.errorbar(sym, align, xerr = sym_err, yerr = align_err, fmt='o', color='black',ecolor='lightgray', elinewidth=3)
plt.xlabel('symmetry')
plt.ylabel('alignment') 
plt.axvline(x=0.87, linestyle='--')
plt.axhline(y=1.0, linestyle='--')
plt.show()

plt.errorbar(peak, align, xerr = peak_err, yerr = align_err, fmt='o', color='black',ecolor='lightgray', elinewidth=3)             
plt.xlabel('peakiness')
plt.ylabel('alignment') 
plt.axvline(x=-0.82, linestyle='--')
plt.axhline(y=1.0, linestyle='--')
plt.show()
  
plt.errorbar(peak, sym, xerr = peak_err, yerr = sym_err, fmt='o', color='black',ecolor='lightgray', elinewidth=3)             
plt.xlabel('peakiness')
plt.ylabel('symmetry') 
plt.axvline(x=-0.82, linestyle='--')
plt.axhline(y=0.87, linestyle='--')
plt.show()

np.savetxt('sym_err_metrics.csv', sym_err)
np.savetxt('align_err_metrics.csv', align_err)
np.savetxt('peak_err_metrics.csv', peak_err)
np.savetxt('sym_metrics.csv', sym)
np.savetxt('align_metrics.csv', align)
np.savetxt('peak_metrics.csv', peak)
