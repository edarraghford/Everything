import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 

sym_err = np.zeros((2,7)) 
align_err = np.zeros((2,7))
peak_err = np.zeros((2,7))
sym = np.zeros(7)
align = np.zeros(7)
peak = np.zeros(7)

for i in range(7):
	file_name = 'updated_final_metrics' + str(i) + '.csv'
	data = pd.read_csv(file_name)
	sym_err[:,i] = np.nanquantile(data['Symmetry'], [0.25,0.75])  
	align_err[:,i] = np.nanquantile(data['Alignment'], [0.25,0.75])
	peak_err[:,i] = np.nanquantile(data['Peakiness'], [0.25,0.75])
	sym[i] = np.nanmedian(data['Symmetry'])  
	align[i] = np.nanmedian(data['Alignment'])
	peak[i] = np.nanmedian(data['Peakiness'])

sym_err = np.abs(sym_err-sym) 
peak_err = np.abs(peak_err-peak) 
align_err = np.abs(align_err-align) 

old_sym = [0.851, 0.372, 0.932, 0.905, 1.346, 0.664, 0.881]
old_sym_err = [0.084, 0.026, 0.075, 0.155, 0.094, 0.036, 0.027]
old_peak = [-0.605, -0.651, -0.617, -1.005, -0.676, -0.767, -0.464] 
old_peak_err = [0.046, 0.037, 0.039, 0.097, 0.034, 0.020, 0.015] 
old_align = [1.08, 1.19, 1.31, 0.90, 1.61, 1.18, 1.28]
old_align_err = [0.13, 0.09, 0.10, 0.18, 0.12, 0.07, 0.06] 

labels = ['macs039', 'macs0417', 'macs0429', 'macs0451', 'macs1115', 'macs2211', 'rxj1347'] 
labels2 = ['039', '0417', '0429', '0451', '1115', '2211', '1347']
fig, ax = plt.subplots()
ax.errorbar(sym, align, xerr = sym_err, yerr = align_err, fmt='o', color='black',ecolor='lightgray', elinewidth=3)
ax.errorbar(old_sym, old_align, xerr = old_sym_err, yerr = old_align_err, fmt='x', color='blue',ecolor='lightblue', elinewidth=1)
ax.set_xlabel('symmetry')
ax.set_ylabel('alignment') 
ax.axvline(x=0.87, linestyle='--')
ax.axhline(y=1.0, linestyle='--')

for i in range(7):
	ax.annotate(labels[i], (sym[i]+0.01, align[i]+0.01), c ='r', size=6, weight='bold') 
	ax.annotate(labels[i], (old_sym[i]+0.01, old_align[i]+0.01), c ='black', size=6, weight='bold')
plt.show()

fig, ax = plt.subplots()
ax.errorbar(peak, align, xerr = peak_err, yerr = align_err, fmt='o', color='black',ecolor='lightgray', elinewidth=3)             
ax.errorbar(old_peak, old_align, xerr = old_peak_err, yerr = old_align_err, fmt='x', color='blue',ecolor='lightblue', elinewidth=1)
ax.set_xlabel('peakiness')
ax.set_ylabel('alignment') 
ax.axvline(x=-0.82, linestyle='--')
ax.axhline(y=1.0, linestyle='--')
for i in range(7):
	ax.annotate(labels[i], (peak[i]+0.01, align[i]+0.01), c ='r', size=6, weight='bold')
	ax.annotate(labels[i], (old_peak[i]+0.01, old_align[i]+0.01), c ='black', size=6, weight='bold')
plt.show()

fig, ax = plt.subplots()
ax.errorbar(peak, sym, xerr = peak_err, yerr = sym_err, fmt='o', color='black',ecolor='lightgray', elinewidth=3)             
ax.errorbar(old_peak, old_sym, xerr = old_peak_err, yerr = old_sym_err, fmt='x', color='blue',ecolor='lightblue', elinewidth=1)
ax.set_xlabel('peakiness')
ax.set_ylabel('symmetry') 
ax.axvline(x=-0.82, linestyle='--')
ax.axhline(y=0.87, linestyle='--')
for i in range(7):
	ax.annotate(labels[i], (peak[i]+0.01, sym[i]+0.01), c ='r', size=6, weight='bold')
	ax.annotate(labels[i], (old_peak[i]+0.01, old_sym[i]+0.01), c ='black', size=6, weight='bold')
plt.show()

np.savetxt('sym_err_metrics.csv', sym_err)
np.savetxt('align_err_metrics.csv', align_err)
np.savetxt('peak_err_metrics.csv', peak_err)
np.savetxt('sym_metrics.csv', sym)
np.savetxt('align_metrics.csv', align)
np.savetxt('peak_metrics.csv', peak)
